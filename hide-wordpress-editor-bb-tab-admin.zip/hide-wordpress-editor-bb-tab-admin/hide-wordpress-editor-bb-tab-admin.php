<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.funnelandclick.com
 * @since             1.0.0
 * @package           Hide_Wordpress_Editor_Bb_Tab_Admin
 *
 * @wordpress-plugin
 * Plugin Name:       Hide WordPress Editor and Beaver Builder Tab
 * Plugin URI:        https://www.funnelandclick.com
 * Description:       This plugin removes the TinyMCE editor on pages only in WordPress and it also removes the Beaver Builder page builder tab from the admin on pages and posts.
 * Version:           1.0.0
 * Author:            Jonathan Power
 * Author URI:        https://www.funnelandclick.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       hide-wordpress-editor-bb-tab-admin
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'HIDE_WORDPRESS_EDITOR_BB_TAB_ADMIN_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-hide-wordpress-editor-bb-tab-admin-activator.php
 */
function activate_hide_wordpress_editor_bb_tab_admin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-hide-wordpress-editor-bb-tab-admin-activator.php';
	Hide_Wordpress_Editor_Bb_Tab_Admin_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-hide-wordpress-editor-bb-tab-admin-deactivator.php
 */
function deactivate_hide_wordpress_editor_bb_tab_admin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-hide-wordpress-editor-bb-tab-admin-deactivator.php';
	Hide_Wordpress_Editor_Bb_Tab_Admin_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_hide_wordpress_editor_bb_tab_admin' );
register_deactivation_hook( __FILE__, 'deactivate_hide_wordpress_editor_bb_tab_admin' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-hide-wordpress-editor-bb-tab-admin.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_hide_wordpress_editor_bb_tab_admin() {

	$plugin = new Hide_Wordpress_Editor_Bb_Tab_Admin();
	$plugin->run();

}
run_hide_wordpress_editor_bb_tab_admin();

add_action( 'init', 'my_custom_init' );
function my_custom_init() {
    remove_post_type_support( 'page', 'editor' );
}

add_action( 'edit_form_top' , 'power_remove_edit_in_bb' , 90, 1 );

function power_remove_edit_in_bb() {
    remove_action( 'edit_form_after_title' , 'FLBuilderAdminPosts::render' , 10, 1 );
}

