<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.funnelandclick.com
 * @since      1.0.0
 *
 * @package    Hide_Wordpress_Editor_Bb_Tab_Admin
 * @subpackage Hide_Wordpress_Editor_Bb_Tab_Admin/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Hide_Wordpress_Editor_Bb_Tab_Admin
 * @subpackage Hide_Wordpress_Editor_Bb_Tab_Admin/includes
 * @author     Jonathan Power <hello@funnelandclick.com>
 */
class Hide_Wordpress_Editor_Bb_Tab_Admin_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'hide-wordpress-editor-bb-tab-admin',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
